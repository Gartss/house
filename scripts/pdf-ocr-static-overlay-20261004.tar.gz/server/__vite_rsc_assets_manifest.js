export default {
  "clientEntryUrl": "/_next/static/chunks/index-BK5g-vCz.js",
  "clientEntryDeps": {
    "js": [
      "/_next/static/chunks/index-BK5g-vCz.js",
      "/_next/static/chunks/rolldown-runtime-C0FnF6B9.js",
      "/_next/static/chunks/framework-BeEOmv_9.js",
      "/_next/static/chunks/vinext-6xGB_2gV.js"
    ],
    "css": []
  },
  "clientReferenceDeps": {
    "01b765926210": {
      "js": [
        "/_next/static/chunks/house-DC9JakCJ.js",
        "/_next/static/chunks/rolldown-runtime-C0FnF6B9.js",
        "/_next/static/chunks/framework-BeEOmv_9.js",
        "/_next/static/chunks/vinext-6xGB_2gV.js",
        "/_next/static/chunks/property-extras-CBIK7VdL.js",
        "/_next/static/chunks/index-BK5g-vCz.js"
      ],
      "css": []
    },
    "9276801271d6": {
      "js": [
        "/_next/static/chunks/vinext-6xGB_2gV.js",
        "/_next/static/chunks/rolldown-runtime-C0FnF6B9.js",
        "/_next/static/chunks/framework-BeEOmv_9.js",
        "/_next/static/chunks/index-BK5g-vCz.js"
      ],
      "css": []
    },
    "0b874ad30386": {
      "js": [
        "/_next/static/chunks/vinext-6xGB_2gV.js",
        "/_next/static/chunks/rolldown-runtime-C0FnF6B9.js",
        "/_next/static/chunks/framework-BeEOmv_9.js",
        "/_next/static/chunks/index-BK5g-vCz.js"
      ],
      "css": []
    },
    "593f344dc510": {
      "js": [
        "/_next/static/chunks/vinext-6xGB_2gV.js",
        "/_next/static/chunks/rolldown-runtime-C0FnF6B9.js",
        "/_next/static/chunks/framework-BeEOmv_9.js",
        "/_next/static/chunks/index-BK5g-vCz.js"
      ],
      "css": []
    },
    "bad85346fc72": {
      "js": [
        "/_next/static/chunks/vinext-6xGB_2gV.js",
        "/_next/static/chunks/rolldown-runtime-C0FnF6B9.js",
        "/_next/static/chunks/framework-BeEOmv_9.js",
        "/_next/static/chunks/index-BK5g-vCz.js"
      ],
      "css": []
    },
    "15c18cfaeeff": {
      "js": [
        "/_next/static/chunks/layout-segment-context-DeZ2fi8A.js",
        "/_next/static/chunks/rolldown-runtime-C0FnF6B9.js",
        "/_next/static/chunks/framework-BeEOmv_9.js",
        "/_next/static/chunks/vinext-6xGB_2gV.js",
        "/_next/static/chunks/index-BK5g-vCz.js"
      ],
      "css": []
    },
    "8c0f216c4604": {
      "js": [
        "/_next/static/chunks/vinext-6xGB_2gV.js",
        "/_next/static/chunks/rolldown-runtime-C0FnF6B9.js",
        "/_next/static/chunks/framework-BeEOmv_9.js",
        "/_next/static/chunks/index-BK5g-vCz.js"
      ],
      "css": []
    },
    "89c3cac48cb5": {
      "js": [
        "/_next/static/chunks/vinext-6xGB_2gV.js",
        "/_next/static/chunks/rolldown-runtime-C0FnF6B9.js",
        "/_next/static/chunks/framework-BeEOmv_9.js",
        "/_next/static/chunks/index-BK5g-vCz.js"
      ],
      "css": []
    }
  },
  "serverResources": {
    "app/layout.tsx": {
      "js": [],
      "css": [
        "/_next/static/css/index.-aHUXchI.css"
      ]
    }
  }
}